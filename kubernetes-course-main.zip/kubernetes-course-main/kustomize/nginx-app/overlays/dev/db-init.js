console.log('Initializing DB');
console.log('Performing some operations');
console.log('Successfully initialized');